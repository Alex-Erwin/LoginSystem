<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit;
}

require 'db.php';

// Handle booking update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $stmt = $pdo->prepare("UPDATE bookings SET quoted_price = ?, assigned_employee = ? WHERE id = ?");
    $stmt->execute([$_POST['quoted_price'], $_POST['assigned_employee'], $_POST['booking_id']]);
}

// Handle availability save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_availability'])) {
    $emp_id    = $_POST['emp_id'];
    $day       = $_POST['day_of_week'];
    $start     = $_POST['start_time'];
    $end       = $_POST['end_time'];

    // Delete existing entry for that employee/day if there is one
    $stmt = $pdo->prepare("DELETE FROM employee_availability WHERE employee_id = ? AND day_of_week = ?");
    $stmt->execute([$emp_id, $day]);

    // Now insert fresh
    $stmt = $pdo->prepare("INSERT INTO employee_availability (employee_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)");
    $stmt->execute([$emp_id, $day, $start, $end]);
}

// Handle availability delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_availability'])) {
    $stmt = $pdo->prepare("DELETE FROM employee_availability WHERE id = ?");
    $stmt->execute([$_POST['avail_id']]);
}

$bookings = $pdo->query("
    SELECT b.*, u.first_name, u.last_name, u.email,
           e.first_name AS emp_first, e.last_name AS emp_last
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    LEFT JOIN employees e ON b.assigned_employee = e.id
    ORDER BY b.date ASC
")->fetchAll();

$employees = $pdo->query("SELECT * FROM employees")->fetchAll();

// Load availability for all employees
$availability = $pdo->query("
    SELECT ea.*, e.first_name, e.last_name
    FROM employee_availability ea
    JOIN employees e ON ea.employee_id = e.id
    ORDER BY e.first_name, FIELD(ea.day_of_week, 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')
")->fetchAll();

$days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | Fine Lines Lawn Care</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.html">Fine Lines Lawn Care</a>
        <div class="navbar-nav ms-auto">
            <span class="nav-link text-warning">Admin: <?= htmlspecialchars($_SESSION['user_name']) ?></span>
            <a class="nav-link" href="logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="container my-5">
    <h2>Admin Dashboard</h2>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4" id="adminTabs">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#bookings">Bookings</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#availability">Employee Availability</a>
        </li>
    </ul>

    <div class="tab-content">

        <!-- BOOKINGS TAB -->
        <div class="tab-pane fade show active" id="bookings">
            <p class="text-muted">All customer bookings. Assign an employee and set a quoted price.</p>

            <?php if (empty($bookings)): ?>
                <div class="alert alert-info">No bookings yet.</div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Customer</th>
                            <th>Email</th>
                            <th>Service Address</th>
                            <th>Service</th>
                            <th>Date & Time</th>
                            <th>Assigned Employee</th>
                            <th>Quoted Price</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $b): ?>
                        <tr>
                            <td><?= $b['id'] ?></td>
                            <td><?= htmlspecialchars($b['first_name'] . ' ' . $b['last_name']) ?></td>
                            <td><?= htmlspecialchars($b['email']) ?></td>
                            <td><?= htmlspecialchars($b['address']) ?></td>
                            <td><?= htmlspecialchars($b['service_type']) ?></td>
                            <td><?= htmlspecialchars($b['date']) ?></td>
                            <td>
                                <form method="POST" class="d-flex gap-2">
                                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                    <select name="assigned_employee" class="form-select form-select-sm">
                                        <option value="">-- None --</option>
                                        <?php foreach ($employees as $emp): ?>
                                            <option value="<?= $emp['id'] ?>" <?= $b['assigned_employee'] == $emp['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                            </td>
                            <td>
                                    <input type="number" name="quoted_price" class="form-control form-control-sm" value="<?= htmlspecialchars($b['quoted_price'] ?? '') ?>" placeholder="$">
                            </td>
                            <td>
                                    <button type="submit" class="btn btn-sm btn-primary">Save</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

        <!-- AVAILABILITY TAB -->
        <div class="tab-pane fade" id="availability">
            <p class="text-muted">Set the days and hours each employee is available to work.</p>

            <!-- Add Availability Form -->
            <div class="card mb-4">
                <div class="card-header bg-dark text-white">Add / Update Availability</div>
                <div class="card-body">
                    <form method="POST" class="row g-3">
                        <input type="hidden" name="save_availability" value="1">
                        <div class="col-md-3">
                            <label class="form-label">Employee</label>
                            <select name="emp_id" class="form-select" required>
                                <option value="">-- Select --</option>
                                <?php foreach ($employees as $emp): ?>
                                    <option value="<?= $emp['id'] ?>">
                                        <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Day of Week</label>
                            <select name="day_of_week" class="form-select" required>
                                <?php foreach ($days as $d): ?>
                                    <option value="<?= $d ?>"><?= $d ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Start Time</label>
                            <input type="time" name="start_time" class="form-control" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">End Time</label>
                            <input type="time" name="end_time" class="form-control" required>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-success w-100">Save</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Current Availability Table -->
            <?php if (empty($availability)): ?>
                <div class="alert alert-info">No availability set yet. Use the form above to add shifts.</div>
            <?php else: ?>

            <?php
            // Group by employee
            $grouped = [];
            foreach ($availability as $a) {
                $name = $a['first_name'] . ' ' . $a['last_name'];
                $grouped[$name][] = $a;
            }
            ?>

            <?php foreach ($grouped as $empName => $shifts): ?>
            <div class="card mb-3">
                <div class="card-header"><strong><?= htmlspecialchars($empName) ?></strong></div>
                <div class="card-body p-0">
                    <table class="table table-bordered mb-0">
                        <thead class="table-secondary">
                            <tr>
                                <th>Day</th>
                                <th>Start Time</th>
                                <th>End Time</th>
                                <th>Remove</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($shifts as $s): ?>
                            <tr>
                                <td><?= $s['day_of_week'] ?></td>
                                <td><?= date('g:i A', strtotime($s['start_time'])) ?></td>
                                <td><?= date('g:i A', strtotime($s['end_time'])) ?></td>
                                <td>
                                    <form method="POST">
                                        <input type="hidden" name="delete_availability" value="1">
                                        <input type="hidden" name="avail_id" value="<?= $s['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Remove</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endforeach; ?>

            <?php endif; ?>
        </div>

    </div>
</div>

<footer class="bg-dark text-white text-center p-4">
    <p>Fine Lines Lawn Care — Admin Panel</p>
    <p class="mb-0">&copy; 2026 Fine Lines Lawn Care</p>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
    // Keep active tab after form submit
    const hash = window.location.hash;
    if (hash) {
        const tab = document.querySelector(`a[href="${hash}"]`);
        if (tab) tab.click();
    }
</script>
</body>
</html>
